                ; i8080 assembler code
                .project peace.dos
                .tape rk-bin
                
                #define RU

                ORIGIN          equ $E000

                ;###############
                ;## КОНСТАНТЫ ##
                ;###############

                KR580VG75       equ $C000
                KR580VT57       equ $E000
                KR580VV55_KBD   equ $8000
                KR580VV55_PPI   equ $A000
                KR580VI53       equ $9000

                COLS		equ 78
                ROWS		equ 30
                DMA_SIZE        equ COLS * ROWS - 1

                ; Конфигурация PEACE.OS

                SCREEN          equ $76D0
                VARS            equ SCREEN - $D0
                STACK           equ SCREEN - 1
                ROM             equ $F800
                RAM             equ $0000
                
                BUFFER_PATH     equ VARS - 64
                BUFFER_CMD      equ BUFFER_PATH - 64
                BUFFER_PROMPT   equ BUFFER_CMD - 64
                BUFFER_WBMP     equ BUFFER_PROMPT - 2048

                MARGIN_TOP      equ 3
                MARGIN_LEFT     equ 8

                ; Светодиод РУС/ЛАТ
                LED_MASK        equ 00001000b

                ; Видеорежим
                DISPLAY_78X30   equ (ROWS - 1) << 8 | (COLS - 1)
                GRAPH_78X30     equ $C399
                GRAPH_78X30L    equ $D399
                DMA_SIZE_78X30  equ 78 * 30 - 1
                CG              equ $84

                DISPLAY_78X38   equ (38 - 1) << 8 | (COLS - 1)
                GRAPH_78X38     equ $4377
                
                LEGACY_CURSOR   equ $7600
                LEGACY_KBDFLG   equ $7605
                LEGACY_RUSLAT   equ $7606
                LEGACY_HEAP     equ $7631
                LEGACY_VIDEO    equ $F82D
 
                
                ;################
                ;## ПЕРЕМЕННЫЕ ##
                ;################

                ; Системные переменные
                CARRIAGE_ADDR   equ VARS
                CARRIAGE        equ CARRIAGE_ADDR       + 2
                POINTER         equ CARRIAGE            + 2
                KEYBOARD        equ POINTER             + 2
                LAST_KEY        equ KEYBOARD            + 2
                KEYBOARD_DELAY  equ LAST_KEY            + 2
                VECTOR          equ KEYBOARD_DELAY      + 2
                CLOCK           equ VECTOR              + 3
                CMD_STRING      equ CLOCK               + 1
                CMD_PARAMS      equ CMD_STRING          + 2
                ECHO            equ CMD_PARAMS          + 2
                FLAG_I2C        equ ECHO                + 1
                FLAG_CMD        equ FLAG_I2C            + 1
                FLAG            equ FLAG_CMD            + 1
                VARIABLE        equ FLAG                + 1
                HDD             equ VARIABLE            + 1
                FILE_SIZE       equ HDD                 + 1
                TEMPO           equ FILE_SIZE           + 2
                ENVELOPE        equ TEMPO               + 1
                TMP             equ ENVELOPE            + 1

                org ORIGIN

                JMP START
                
                ;org ORIGIN

                ;##########################
                ;## ВЫЗОВ Интерпретатора ##
                ;##########################

                ; HL - указатель на строку команды
                
                SHLD CMD_STRING
                CALL EXEC
                RET

                ;################
                ;## Библиотеки ##
                ;################
                
                .include video.inc
                
                .include io.inc
                
                .include text.inc
                
                .include interpreter.inc
                
                .include functions.inc
                
                .include hdd.inc
                
                .include msg.inc


        START: 

                ;###########################
                ;## Сброс и инициализация ##
                ;###########################
        
                ; Устанавливаем стек
                LXI SP, STACK

                ; Настройка порта клавиатуры        
                LXI H, KR580VV55_KBD + 3
                MVI M, $8A ; КР580ВВ55: A - вывод, B - ввод
                
                ; Настройка ППА
                MVI A, $90 \\ STA KR580VV55_PPI + 3
                MVI A, $80 \\ STA KR580VV55_PPI + 2
                
                ; Сброс ВИ53
                CALL VI53_RST

                ; Включаем светодиод РУС/ЛАТ
                CALL LED_ON

                ; Гасим экран
                MVI A, $20 \\ STA KR580VG75 + 1
                MVI A, $80 \\ STA KR580VT57 + 8

                ; Звуковой сигнал
                LXI B, $8040 \\ CALL BEEP

                ; Выключаем светодиод РУС/ЛАТ
                CALL LED_OFF             

                ; Настройка видеоконтроллера
                CALL HIDE_CURSOR
                CALL VG75_INIT
                
                ; Вектор фоновых подпрограмм
                LXI H, VECTOR \\ MVI M, $C9
                
                ; Путь к файлам
                LXI H, $002F \\ SHLD BUFFER_PATH
                
                ; Последняя выполненная команда
                LXI H, TXT_FILE_AUTO
                LXI D, BUFFER_CMD
                CALL FUNCTION_STRCPY
                
                ; Обнуление переменных
                LXI H, $0000
                SHLD ECHO
                SHLD FLAG_I2C
               
                ; Заголовок
                LXI H, TXT_TITLE \\ CALL PRINT_TEXT

                ;##################
                ;## Запуск диска ##
                ;##################
                
                XRA A \\ CMA \\ STA HDD
                CALL CH376_INIT \\ JNZ NO_HDD
                XRA A \\ STA HDD

                LXI H, TXT_FILE_AUTO
                SHLD CMD_STRING
                XRA A \\ CMA \\ STA ECHO
                CALL EXEC
                JMP PROMPT
                
                NO_HDD:

                ;#####################
                ;## Старт без диска ##
                ;#####################
                
                LXI H, AUTOEXEC_TXT
                CALL AUTOEXEC
                
                PROMPT:

                ;################################
                ;## Работа с командной строкой ##
                ;################################

                ; Командная строка
                LHLD CARRIAGE_ADDR
                SHLD CMD_STRING \\ MVI M, $00

                ; Курсор
                CALL SET_CURSOR
                
                ; Переменная нажатой клавиши
                LXI H, $0000 \\ SHLD LAST_KEY
                

        COMMAND_LINE:
                
                MVI A, $10 \\ STA KEYBOARD_DELAY

                ; Чтение клавиатуры
                CALL GET_KEYBOARD
                
                LXI H, LAST_KEY
                CMP M \\ STA LAST_KEY \\ JNZ KEY_PRESSED
                LXI H, KEYBOARD_DELAY \\ MVI M, $04

                ; Клавиша нажата
                KEY_PRESSED:
                
                ; Клавиша не нажата
                CPI $80 \\ JZ NO_KEY_PRESSED
                
                LXI H, DELAYS_AND_CLICKS
                PUSH H

                ; Клавиша HOME * СМЕНА ВИДЕОРЕЖИМА *
                KEY_HOME: CPI $0C \\ JNZ KEY_CLS
                CALL VG75_MODES
                RET

                ; Клавиша CLS
                KEY_CLS: CPI $1F \\ JNZ KEY_F1
                CALL VG75_INIT
                SHLD CMD_STRING \\ MVI M, $00
                RET

                ; Клавиша F1
                KEY_F1: CPI $00 \\ JNZ KEY_F2
                CALL EXEC_HELP
                CALL EOL
                SHLD CMD_STRING
                RET

                ; Клавиша F2
                KEY_F2: CPI $01 \\ JNZ KEY_F3
                RET

                ; Клавиша F3
                KEY_F3: CPI $02 \\ JNZ KEY_F4
                RET

                ; Клавиша F4
                KEY_F4: CPI $03 \\ JNZ KEY_F5
                RET

                ; Клавиша F5
                KEY_F5: CPI $04 \\ JNZ KEY_7F
                RET

                ; Клавиша ЗБ
                KEY_7F: CPI $7F \\ JNZ KEY_LEFT
                LHLD CARRIAGE
                XRA A \\ ORA L \\ RZ
                LHLD CARRIAGE \\ DCR L \\ CALL CARRIAGE_SET
                LHLD CARRIAGE_ADDR \\ CALL FUNCTION_SHIFT_LEFT
                RET
                
                ; Стрелка влево
                KEY_LEFT: CPI $08 \\ JNZ KEY_RIGHT
                XRA A 
                LHLD CARRIAGE \\ ORA L \\ RZ
                DCR L \\ CALL CARRIAGE_SET
                RET
                
                ; Стрелка вправо
                KEY_RIGHT: CPI $18 \\ JNZ KEY_UP
                XRA A 
                LHLD CARRIAGE_ADDR \\ ORA M \\ RZ
                LHLD CARRIAGE \\ INR L \\ CALL CARRIAGE_SET
                RET
                
                ; Стрелка вверх
                KEY_UP: CPI $19 \\ JNZ KEY_DOWN
                XRA A 
                LHLD CARRIAGE \\ ORA L \\ RNZ
                LXI H, BUFFER_CMD
                CALL PRINT_TEXT
                CALL CARRIAGE_EOL
                RET
                
                ; Стрелка вниз
                KEY_DOWN: CPI $1A \\ JNZ KEY_ENTER
                XRA A 
                LHLD CARRIAGE \\ ORA L \\ RNZ
                LXI H, BUFFER_PATH
                CALL PRINT_TEXT
                CALL CARRIAGE_EOL
                RET
                
                ; Клавиша ВК
                KEY_ENTER: CPI $0D \\ JNZ KEY_MASK
                LHLD CMD_STRING
                CALL CARRIAGE_EOL
                CALL EXEC
                RET
                
                ; Маскирование
                KEY_MASK: CPI $20 \\ JNC KEY_ELSE
                RET

                ; Другие клавиши
                KEY_ELSE:
                
                POP H

                LHLD CMD_STRING \\ CALL FUNCTION_STRLEN
                MVI A, 63 \\ CMP E \\ JZ NO_KEY_PRESSED ; Ограничение длины строки
                LHLD CARRIAGE_ADDR \\ DCR L \\ CALL FUNCTION_SHIFT_RIGHT
                LXI H, LAST_KEY \\ CALL PRINT_TEXT
                
                DELAYS_AND_CLICKS:

                CALL SET_CURSOR
                MVI A, $05 \\ LXI B, $0010 \\ CALL BEEP_DECAY
                
                LDA KEYBOARD_DELAY
                
                KEYBOARD_DELAY_LOOP:
                
                PUSH PSW
                
                CALL GET_KEYBOARD
                LXI H, LAST_KEY
                CMP M \\ JZ . + 7
                POP PSW \\ JMP NO_KEY_PRESSED
                CALL VG75_READY

                POP PSW
                DCR A \\ JNZ KEYBOARD_DELAY_LOOP
                
                ; Клавиши не обрабатываются
                NO_KEY_PRESSED:
                
                LXI H, CLOCK \\ INR M
                CALL VECTOR

                JMP COMMAND_LINE


                ;###################################
                ;## Монитор из дистрибутива EMU80 ##
                ;###################################

                org $F800

                .include monitor.inc
