                ; i8080 assembler code
                .project tracker.bin
                .tape rk-bin

                ;###############
                ;## КОНСТАНТЫ ##
                ;###############

                OS              equ $E000

                KR580VG75       equ $C000
                KR580VV55       equ $8000
                KR580VI53       equ $9000
                
                BUFFER          equ $0200

                ORG $0000
                
                JMP START

                ;################
                ;## ПЕРЕМЕННЫЕ ##
                ;################
                
                TEMPO:          db $00
                ENVELOPE:       db $00

                SCALES:         
                ;  C      C#     D      D#     E      F      F#     G      G#     A      A#     B
                dw $8000, $78DF, $7223, $6BC7, $65C6, $601A, $5AC0, $55B2, $50EB, $4C69, $4827, $4422
                dw $4057, $3CC1, $395F, $362C, $3328, $304E, $2D9D, $2B13, $28AC, $2668, $2445, $223F
                dw $2057, $1E8A, $1CD6, $1B3B, $19B7, $1848, $16EE, $15A7, $1472, $134E, $123B, $1137
                dw $1041, $0F5A, $0E7F, $0DB0, $0CED, $0C35, $0B86, $0AE2, $0A47, $09B4, $092A, $08A7
                dw $082C, $07B7, $0749, $06E1, $067F, $0623, $05CB, $0579, $052B, $04E1, $049B, $045A
                
                CMD_TITLE:      db "TEXT 0100", $00
                CMD_LOAD:       db "LOAD 0200 ", $00, $00, $00, $00, $00, $00, $00, $00, $00, $00, $00, $00, $00
                
                ORG $0100
                
                TXT_TITLE:      db "PWM TRACKER 2026 BY DMITRY IVANOV", $00

                ; Библиотеки


        FUNCTION_STRCPY:
        
                ; HL - Начало строки
                ; DE - Куда копировать

                MOV A, M
                ANA A \\ RZ
                CPI $20 \\ RZ
                STAX D
                INX H \\ INX D
                JMP FUNCTION_STRCPY

                RET


        VG75_READY: ; Ждем обратный ход

                LXI H, KR580VG75 + 1
		MOV A, M
		MOV A, M \\ ANI $20 \\ JZ . - 3
                RET            
                

        VI53_RST: ; Сброс ВИ53
        
                LXI H, KR580VI53 + 3
                MVI M, $36 \\ MVI M, $66 \\ MVI M, $B6
                RET


        PWM:

		; Звук для платы SRAM
                LXI H, KR580VV55 + 2
                MVI M, 00000110b
                
                ;############################
                ;## Настройка каналов ВИ53 ##
                ;############################
                
                ; Канал 0 - младший байт, выдача сигнала прерывания по конечному числу
                ; Канал 1 - младший байт, ждущий мультивибратор
                ; Канал 2 - слово, меандр
                
                LXI H, KR580VI53 + 3
                MVI M, $12 \\ MVI M, $54 \\ MVI M, $B6

                ; Канал тактовой частоты
                MVI A, $3F
                DCR L \\ DCR L \\ MOV M, A
                
                ; Канал амплитуды
                DCR L \\ MOV M, A
                STA ENVELOPE

                RET

        GET_ANYKEY:

                LXI H, KR580VV55
		MVI M, $00
		INR L
		MOV A, M
		CPI $FF

                RET


        START: 

                ;###########################
                ;## Сброс и инициализация ##
                ;###########################

                ;Загрузка файла по параметрам
                
                PUSH H
                LXI H, CMD_TITLE \\ CALL OS + 3
                POP H

                LXI D, CMD_LOAD + 10
                CALL FUNCTION_STRCPY
                LXI H, CMD_LOAD \\ CALL OS + 3
                RNZ

                CALL PWM

                ; Воспроизведение
                LXI D, BUFFER + 1
                
                EXEC_PLAY_LOOP:

                ; Длительность ноты
                LDAX D \\ CPI $FF \\ JZ EXEC_PLAY_STOP
                STA TEMPO \\ INX D 

                ; Индекс ноты
                LDAX D \\ INX D 
                
                PUSH D
                
                CPI $FE \\ JZ EXEC_PLAY_ENVELOPE
                
                LXI B, $0000
                LXI H, SCALES
                ADD A \\ MOV C, A
                DAD B
                MOV C, M \\ INX H \\ MOV B, M
                
                ; Загрузка делителя частоты в ВИ63
                LXI H, KR580VI53 + 2
                MOV M, C \\ MOV M, B
                XRA A \\ STA ENVELOPE

                EXEC_PLAY_ENVELOPE:

                LHLD TEMPO \\ XCHG
                LXI B, KR580VI53

                EXEC_PLAY_ENVELOPE_LOOP:
                
                CALL VG75_READY
                
                MOV A, D \\ CPI $3F \\ JNC EXEC_PLAY_ENVELOPE_TIME
                LDA BUFFER \\ ADD D \\ MOV D, A
                STAX B
                
                EXEC_PLAY_ENVELOPE_TIME:
                
                DCR E \\ JNZ EXEC_PLAY_ENVELOPE_LOOP
                
                MOV A, D \\ STA ENVELOPE
                
                POP D
                
                CALL GET_ANYKEY \\ CPI 11111011B
                JNZ EXEC_PLAY_LOOP
                
                EXEC_PLAY_STOP:
                
                CALL VI53_RST
                
                RET
